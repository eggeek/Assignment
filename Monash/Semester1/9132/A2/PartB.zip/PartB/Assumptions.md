# Assumptions

- Official represent for only one country.
- Official has only one role.
- Vechicle would not break down during a travel.(We do not need change vechicle during the travel)
- Our system is fast enough to deal with emergency booking. (It is not necessary to distinguish emergency booking from normal booking)
- Registration number is unchangeable, so the registration number can identify a vehicle.
- Maintenance and Repair would never change vehicle `feature`, `seats_num`, `color`, but may change `odometer`.
- A location has only on location type. (If 2 same places have diffierent type, we regard them
  as different places)
- `lincence_number` is unique.
- All odometer fields are managed by application layer, so we do not need to write trigger for them
- All availability fields are managed by application layer, so we do not need to write trigger for them (except writing log to `AUDIT` table)
