create or replace trigger maintain_count
after insert on qualifications
for each row

begin
  update DRIVER
    set QUALIFICATIONS_COUNT = QUALIFICATIONS_COUNT + 1
    where DRIVER_ID = :new.Driver_driver_id;
end;